TAREEQ - سحب جروبات فيسبوك (Chrome Extension)
================================================

تثبيت (مرة واحدة):
  1. افتح Chrome → chrome://extensions
  2. فعّل "Developer mode" (أعلى-يمين).
  3. اضغط "Load unpacked" (تحميل غير مضغوط).
  4. اختر مجلد: tools\fb-groups-scraper-extension
  5. ظهر extension "TAREEQ - سحب جروبات" في قائمة Extensions.

الاستخدام:
  1. افتح Facebook -> https://www.facebook.com/groups
  2. مرّر للأسفل (scroll) لتحميل كل الجروبات.
  3. ستجد زر "📥 سحب جروبات TAREEQ" (أسفل-يمين).
  4. اضغطه -> سحب تلقائي -> حمّل ملف tareeq-groups.txt
  5. لوحة TAREEQ -> جروبات فيسبوك -> "رفع ملف" -> اختر tareeq-groups.txt -> "إضافة الكل"

ملاحظة:
  - Extension يتجاوز حماية Facebook (CSP) because it runs as content script.
  - لا حاجة لـ Tampermonkey.
  - إذا button not visible: refresh page (F5).
