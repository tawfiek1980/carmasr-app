// TAREEQ Bridge - runs on the admin page (tareeq-eg.vercel.app/admin*)
// Relays between the React app (via window.postMessage) and the extension background.

(function () {
  'use strict';

  function postToPage(payload) {
    window.postMessage({ source: 'tareeq-ext', ...payload }, '*');
  }

  // Listen for messages from background
  chrome.runtime.onMessage.addListener((msg) => {
    if (msg && msg.source === 'tareeq-bg') {
      postToPage(msg);
    }
  });

  // Listen for messages from the page (React app)
  window.addEventListener('message', (e) => {
    if (e.source !== window) return;
    const d = e.data;
    if (!d || d.source !== 'tareeq-app') return;
    if (d.type === 'START_QUEUE') {
      chrome.runtime.sendMessage({ type: 'START_QUEUE', queue: d.queue, adTitle: d.adTitle, images: d.images, text: d.text, texts: d.texts, mode: d.mode }, (res) => {
        postToPage({ type: 'STARTED', ok: !!(res && res.ok), state: res && res.state });
      });
    } else if (d.type === 'SYNC') {
      chrome.runtime.sendMessage({ type: 'SYNC', idx: d.idx, posted: d.posted }, () => {});
    } else if (d.type === 'GET_STATE') {
      chrome.runtime.sendMessage({ type: 'GET_STATE' }, (res) => {
        postToPage({ type: 'STATE', state: res && res.state });
      });
    } else if (d.type === 'STOP') {
      chrome.runtime.sendMessage({ type: 'STOP' }, () => {
        postToPage({ type: 'STOPPED' });
      });
    }
  });

  // Announce readiness
  setTimeout(() => postToPage({ type: 'BRIDGE_READY' }), 300);
})();