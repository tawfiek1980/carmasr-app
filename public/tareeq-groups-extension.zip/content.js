// TAREEQ FB Groups Scraper - Content Script
// Runs on https://www.facebook.com/groups*

(function () {
  'use strict';

  // ─── Inject floating button ───
  function injectButton() {
    if (document.getElementById('tareeq-ext-btn')) return;
    const btn = document.createElement('button');
    btn.id = 'tareeq-ext-btn';
    btn.textContent = '📥 سحب جروبات TAREEQ';
    btn.style.cssText = 'position:fixed;bottom:20px;right:20px;z-index:999999;background:linear-gradient(135deg,#f97316,#ea580c);color:#fff;border:none;border-radius:14px;padding:12px 18px;font-size:14px;font-weight:700;box-shadow:0 8px 24px rgba(249,115,22,0.4);cursor:pointer;font-family:system-ui,sans-serif;direction:rtl;';
    document.body.appendChild(btn);

    const status = document.createElement('div');
    status.id = 'tareeq-ext-status';
    status.style.cssText = 'position:fixed;bottom:70px;right:20px;z-index:999999;background:#0D1B2A;color:#fff;border-radius:10px;padding:8px 12px;font-size:12px;font-family:system-ui,sans-serif;direction:rtl;max-width:260px;display:none;';
    document.body.appendChild(status);

    function showStatus(msg) { status.textContent = msg; status.style.display = 'block'; }
    function hideStatus() { status.style.display = 'none'; }

    function collect() {
      const M = new Map();
      document.querySelectorAll('a[href*="/groups/"]').forEach(a => {
        const h = a.getAttribute('href') || a.href || '';
        const m = h.match(/\/groups\/(\d{5,})(?:\/|$|[?#])/);
        if (!m) return;
        const id = m[1];
        const t = (a.getAttribute('aria-label') || a.textContent || '').replace(/\s+/g, ' ').trim().slice(0, 120);
        const p = M.get(id);
        if (!p || (t && t.length > (p.n || '').length)) M.set(id, { n: t || id });
      });
      return M;
    }

    function scrollDown() {
      window.scrollTo(0, document.body.scrollHeight);
      const el = document.scrollingElement || document.documentElement;
      if (el) el.scrollTop = el.scrollHeight;
      const mn = document.querySelector('[role="main"]');
      if (mn && mn.scrollHeight > mn.clientHeight + 200) mn.scrollTop = mn.scrollHeight;
      document.querySelectorAll('div').forEach(d => {
        const s = getComputedStyle(d);
        if (s.overflowY === 'auto' || s.overflowY === 'scroll') d.scrollTop = d.scrollHeight;
      });
    }

    btn.addEventListener('click', async () => {
      btn.disabled = true;
      btn.textContent = '⏳ جاري السحب...';
      showStatus('بدء السحب — لا تغلق الصفحة');

      const M = new Map();
      let last = -1, lastM = -1, same = 0;
      for (let i = 0; i < 500; i++) {
        collect().forEach((v, k) => {
          const p = M.get(k);
          if (!p || (v.n && v.n.length > (p.n || '').length)) M.set(k, v);
        });
        scrollDown();
        await new Promise(r => setTimeout(r, 700));
        const hh = document.body.scrollHeight + (document.scrollingElement ? document.scrollingElement.scrollHeight : 0);
        if (hh === last && M.size === lastM) {
          if (++same >= 7) break;
        } else {
          same = 0;
        }
        last = hh;
        lastM = M.size;
        showStatus('تم سحب ' + M.size + ' جروب — مرّر للأسفل...');
      }
      collect().forEach((v, k) => {
        const p = M.get(k);
        if (!p || (v.n && v.n.length > (p.n || '').length)) M.set(k, v);
      });

      const rows = [...M.entries()];
      if (!rows.length) {
        showStatus('لم يُعثر على أي جروب — تأكد أنك في صفحة Groups');
        btn.disabled = false;
        btn.textContent = '📥 سحب جروبات TAREEQ';
        return;
      }

      const txt = rows.map(e => (e[1].n || e[0]) + ' | https://www.facebook.com/groups/' + e[0] + '/').join('\n');
      // Send to background for download (or use blob)
      const blob = new Blob([txt], { type: 'text/plain;charset=utf-8' });
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = 'tareeq-groups.txt';
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
      URL.revokeObjectURL(url);
      if (navigator.clipboard && navigator.clipboard.writeText) navigator.clipboard.writeText(txt).catch(() => {});

      showStatus('✅ تم سحب ' + rows.length + ' جروب — حُمّل ملف tareeq-groups.txt');
      btn.textContent = '✅ تم (' + rows.length + ')';
      alert('تم تجهيز ' + rows.length + ' جروب ✓\n\nحمّل ملف tareeq-groups.txt\n\nافتح لوحة TAREEQ → جروبات فيسبوك → رفع ملف → اختر tareeq-groups.txt → إضافة الكل');

      setTimeout(() => {
        btn.disabled = false;
        btn.textContent = '📥 سحب جروبات TAREEQ';
        hideStatus();
      }, 8000);
    });
  }

  // ─── TAREEQ auto-open composer (when opened with ?tareeq=1) ───
  function isTareeqOpen() {
    try { return new URLSearchParams(window.location.search).get('tareeq') === '1'; } catch { return false; }
  }

  function findComposerTrigger() {
    const candidates = [
      '[aria-label*="Write something"]',
      '[aria-label*="اكتب"]',
      '[aria-label*="Write a public post"]',
      '[aria-label*="Create a public post"]',
      'div[role="button"]',
    ];
    for (const sel of candidates) {
      const nodes = document.querySelectorAll(sel);
      for (const n of nodes) {
        const txt = (n.textContent || n.getAttribute('aria-label') || '').trim();
        if (/write|اكتب|نشر|post|منشور/i.test(txt) && txt.length < 60) return n;
      }
    }
    // fallback: first role=button with composer-like placeholder
    const all = document.querySelectorAll('div[role="button"]');
    for (const n of all) {
      const ph = n.getAttribute('aria-placeholder') || n.getAttribute('placeholder') || '';
      if (/write|اكتب/i.test(ph)) return n;
    }
    return null;
  }

  async function autoOpenComposer() {
    if (!isTareeqOpen()) return;
    // Wait for FB to render composer area
    let tries = 0;
    const tick = async () => {
      const btn = findComposerTrigger();
      if (btn) {
        try { btn.click(); } catch {}
        // Show a small floating hint
        if (!document.getElementById('tareeq-auto-hint')) {
          const hint = document.createElement('div');
          hint.id = 'tareeq-auto-hint';
          hint.style.cssText = 'position:fixed;top:12px;right:12px;z-index:999999;background:#f97316;color:#fff;border-radius:12px;padding:10px 14px;font-size:13px;font-weight:700;font-family:system-ui,sans-serif;direction:rtl;box-shadow:0 8px 24px rgba(0,0,0,0.3);max-width:320px;';
          hint.textContent = '✅ TAREEQ: الصق المحتوى (Ctrl+V) → انشر → ارجع للوحة واضغط Enter (التالي)';
          document.body.appendChild(hint);
          setTimeout(() => { hint.style.opacity = '0.6'; }, 8000);
        }
        return;
      }
      if (++tries < 40) setTimeout(tick, 500);
    };
    tick();
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', autoOpenComposer);
  } else {
    autoOpenComposer();
  }
  // Re-run on SPA navigation
  let lastUrl = location.href;
  const urlObs = new MutationObserver(() => {
    if (location.href !== lastUrl) { lastUrl = location.href; setTimeout(autoOpenComposer, 1200); }
  });
  urlObs.observe(document.body, { childList: true, subtree: true });

  // ─── Floating publish controls on FB group pages (when queue is active) ───
  function injectFloatControls() {
    if (document.getElementById('tareeq-float-ctrl')) return;
    const box = document.createElement('div');
    box.id = 'tareeq-float-ctrl';
    box.style.cssText = 'position:fixed;bottom:20px;left:20px;z-index:999999;display:flex;gap:8px;direction:rtl;font-family:system-ui,sans-serif;';
    const mkBtn = (label, bg, onClick) => {
      const b = document.createElement('button');
      b.textContent = label;
      b.style.cssText = 'border:none;border-radius:12px;padding:10px 16px;font-size:13px;font-weight:800;color:#fff;cursor:pointer;box-shadow:0 8px 24px rgba(0,0,0,0.35);';
      b.style.background = bg;
      b.addEventListener('click', onClick);
      return b;
    };
    const advanceBtn = mkBtn('✅ نشرت (التالي)', 'linear-gradient(135deg,#10b981,#059669)', () => {
      chrome.runtime.sendMessage({ type: 'ADVANCE' }, (res) => {
        if (res && res.ok) {
          // close this tab shortly after opening next
          setTimeout(() => { try { window.close(); } catch {} }, 800);
        }
      });
    });
    const skipBtn = mkBtn('⏭ تخطي', 'linear-gradient(135deg,#64748b,#475569)', () => {
      chrome.runtime.sendMessage({ type: 'SKIP' }, (res) => {
        if (res && res.ok) {
          setTimeout(() => { try { window.close(); } catch {} }, 800);
        }
      });
    });
    const stopBtn = mkBtn('⏹ إيقاف', 'linear-gradient(135deg,#ef4444,#dc2626)', () => {
      if (!confirm('إيقاف الطابور؟')) return;
      chrome.runtime.sendMessage({ type: 'STOP' }, () => {
        try { window.close(); } catch {}
      });
    });
    box.appendChild(advanceBtn);
    box.appendChild(skipBtn);
    box.appendChild(stopBtn);
    document.body.appendChild(box);
  }

  // ─── نسخ صورة الإعلان للحافظة (best effort) ───
  async function copyImageToClipboard(url) {
    try {
      const r = await fetch(url, { mode: 'cors', cache: 'force-cache' });
      if (!r.ok) return false;
      const blob = await r.blob();
      const bmp = await createImageBitmap(blob);
      const canvas = document.createElement('canvas');
      canvas.width = bmp.width; canvas.height = bmp.height;
      const ctx = canvas.getContext('2d');
      if (!ctx) return false;
      ctx.drawImage(bmp, 0, 0);
      const png = await new Promise(res => canvas.toBlob(res, 'image/png'));
      if (!png) return false;
      await navigator.clipboard.write([new ClipboardItem({ 'image/png': png })]);
      return true;
    } catch {
      return false;
    }
  }

  // ─── نسخ نص البوست للحافظة (best effort) ───
  async function copyTextToClipboard(text) {
    if (!text) return false;
    try {
      await navigator.clipboard.writeText(text);
      return true;
    } catch {
      try {
        const ta = document.createElement('textarea');
        ta.value = text;
        ta.style.cssText = 'position:fixed;top:0;left:0;opacity:0;pointer-events:none;';
        document.body.appendChild(ta);
        ta.focus();
        ta.select();
        const ok = document.execCommand('copy');
        ta.remove();
        return ok;
      } catch {
        return false;
      }
    }
  }

  // ─── تجهيز المنشور تلقائيًا: ملء النص أو رفع الصور ───
  function waitFor(fn, timeoutMs) {
    return new Promise(resolve => {
      const started = Date.now();
      const tick = () => {
        let v = null;
        try { v = fn(); } catch {}
        if (v) return resolve(v);
        if (Date.now() - started >= timeoutMs) return resolve(null);
        setTimeout(tick, 400);
      };
      tick();
    });
  }

  function isPostBox(n) {
    const label = ((n.getAttribute('aria-label') || '') + ' ' + (n.getAttribute('data-placeholder') || '')).toLowerCase();
    return /post|منشور|اكتب|write|create|بماذا|شيئ/.test(label);
  }

  function findComposerInput() {
    const inDialog = [...document.querySelectorAll('div[role="dialog"] div[contenteditable="true"]')]
      .filter(n => n.offsetParent !== null);
    if (inDialog.length) return inDialog[0];
    const boxes = [...document.querySelectorAll('div[contenteditable="true"][role="textbox"]')]
      .filter(n => n.offsetParent !== null && isPostBox(n));
    return boxes[0] || null;
  }

  async function fillComposerText(text) {
    if (!text) return false;
    const el = await waitFor(findComposerInput, 20000);
    if (!el) return false;
    try {
      el.focus();
      const sel = window.getSelection();
      const range = document.createRange();
      range.selectNodeContents(el);
      sel.removeAllRanges();
      sel.addRange(range);
      let inserted = false;
      try { inserted = document.execCommand('insertText', false, text); } catch {}
      if (!inserted) {
        el.textContent = text;
        try {
          el.dispatchEvent(new InputEvent('input', { bubbles: true, inputType: 'insertText', data: text }));
        } catch {
          el.dispatchEvent(new Event('input', { bubbles: true }));
        }
      }
      return ((el.innerText || el.textContent || '').trim().length > 0);
    } catch {
      return false;
    }
  }

  async function fetchImageBlob(url) {
    try {
      const r = await fetch(url, { mode: 'cors', cache: 'force-cache' });
      if (r.ok) {
        const b = await r.blob();
        if (/^image\//.test(b.type) && b.size > 0 && b.size < 9 * 1024 * 1024) return b;
      }
    } catch { /* CORS — نجرب من الـ background */ }
    try {
      const res = await chrome.runtime.sendMessage({ type: 'FETCH_IMAGE', url });
      if (res && res.ok && res.base64) {
        const bin = atob(res.base64);
        const bytes = new Uint8Array(bin.length);
        for (let i = 0; i < bin.length; i++) bytes[i] = bin.charCodeAt(i);
        return new Blob([bytes], { type: res.mime || 'image/jpeg' });
      }
    } catch { /* ignore */ }
    return null;
  }

  async function attachImagesToComposer(urls) {
    if (!urls || !urls.length) return 0;
    const input = await waitFor(() => {
      const dialog = document.querySelector('div[role="dialog"]');
      const scopes = [dialog, document].filter(Boolean);
      for (const scope of scopes) {
        const list = [...scope.querySelectorAll('input[type="file"][accept*="image"]')];
        const hit = list.find(n => !n.disabled);
        if (hit) return hit;
      }
      return null;
    }, 20000);
    if (!input) return 0;
    const dt = new DataTransfer();
    let added = 0;
    for (const url of urls.slice(0, 5)) {
      const blob = await fetchImageBlob(url);
      if (!blob) continue;
      const type = blob.type || 'image/jpeg';
      const ext = (type.split('/')[1] || 'jpg').replace('jpeg', 'jpg');
      try {
        dt.items.add(new File([blob], 'tareeq-' + (added + 1) + '.' + ext, { type }));
        added += 1;
      } catch { /* skip */ }
    }
    if (!dt.files.length) return 0;
    try {
      input.files = dt.files;
      input.dispatchEvent(new Event('change', { bubbles: true }));
      return added;
    } catch {
      return 0;
    }
  }

  function showHint(state, copied, textMode, info) {
    let hint = document.getElementById('tareeq-auto-hint');
    if (!hint) {
      hint = document.createElement('div');
      hint.id = 'tareeq-auto-hint';
      hint.style.cssText = 'position:fixed;top:12px;right:12px;z-index:999999;background:#f97316;color:#fff;border-radius:12px;padding:10px 14px;font-size:13px;font-weight:800;font-family:system-ui,sans-serif;direction:rtl;box-shadow:0 8px 24px rgba(0,0,0,0.3);max-width:340px;line-height:1.7;';
      document.body.appendChild(hint);
    }
    const d = info || {};
    const n = state.queue.length;
    const i = Math.min(state.idx + 1, n);
    let body;
    if (textMode) {
      body = d.filled
        ? '✅ النص اتحط جوه المنشور — راجعه واضغط نشر'
        : (copied ? '✅ النص اتنسخ — الصقه (Ctrl+V)' : 'انسخ نص البوست من الإضافة والصقه (Ctrl+V)');
    } else {
      body = d.attached
        ? ('✅ اترفعت ' + d.attached + ' صورة — راجعهم واضغط نشر')
        : (copied ? '✅ الصورة اتنسخت — الصقها (Ctrl+V)' : 'افتح «صورة/فيديو» وارفع صور الإعلان');
    }
    hint.innerHTML = 'TAREEQ — جروب ' + i + ' من ' + n + '<br>'
      + body + ' → انشر → اضغط <b>✅ نشرت (التالي)</b>';
  }

  // يجهّز المنشور (نص أو صور) — ويحاول تلقائيًا، ولو فشل ينسخ للحافظة
  async function activateQueue(st) {
    injectFloatControls();
    const textMode = st.mode === 'text';
    const groupId = String(st.queue[st.idx] || '');
    const perGroup = st.texts && st.texts[groupId];
    const groupText = (perGroup && String(perGroup).trim()) || st.text || '';
    const key = 'tareeq_ready_' + location.pathname + '_' + st.idx;
    if (sessionStorage.getItem(key)) { showHint(st, false, textMode, {}); return; }
    const info = { filled: false, attached: 0, custom: !!(perGroup && String(perGroup).trim()) };
    let copied = false;
    if (textMode && groupText) {
      info.filled = await fillComposerText(groupText);
      if (!info.filled) copied = await copyTextToClipboard(groupText);
    } else {
      info.attached = await attachImagesToComposer(st.images || []);
      if (!info.attached) copied = await copyImageToClipboard((st.images || [])[0]);
    }
    sessionStorage.setItem(key, '1');
    showHint(st, copied, textMode, info);
  }

  // بيدوّر على طابور شغّال لحد 2 دقيقة، وبيوقف أول ما يلاقيه
  async function maybeShowFloatControls(attempt) {
    attempt = attempt || 0;
    try {
      const res = await chrome.runtime.sendMessage({ type: 'GET_STATE' });
      const st = res && res.ok ? res.state : null;
      const active = st && Array.isArray(st.queue) && st.queue.length && st.idx < st.queue.length;
      if (active) {
        await activateQueue(st);
        return;
      }
    } catch {}
    if (attempt < 60) setTimeout(() => maybeShowFloatControls(attempt + 1), 2000);
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', () => { injectButton(); maybeShowFloatControls(); });
  } else {
    injectButton();
    maybeShowFloatControls();
  }
  // Re-inject if FB re-renders (SPA navigation)
  const observer = new MutationObserver(() => {
    if (!document.getElementById('tareeq-ext-btn')) injectButton();
  });
  observer.observe(document.body, { childList: true, subtree: true });
})();
