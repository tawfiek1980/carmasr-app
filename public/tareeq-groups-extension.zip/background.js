// TAREEQ FB Publisher - Background Service Worker
// Bridges the admin page (tareeq-eg.vercel.app/admin) and Facebook group pages.

const STORAGE_KEY = 'tareeq_pub_state';

async function getState() {
  const r = await chrome.storage.local.get(STORAGE_KEY);
  return r[STORAGE_KEY] || { queue: [], idx: 0, posted: {}, adTitle: '', images: [], text: '', mode: 'image', updatedAt: 0 };
}

async function setState(s) {
  s.updatedAt = Date.now();
  await chrome.storage.local.set({ [STORAGE_KEY]: s });
}

chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  (async () => {
    const state = await getState();
    if (msg.type === 'START_QUEUE') {
      const next = {
        queue: Array.isArray(msg.queue) ? msg.queue : [],
        idx: 0,
        posted: {},
        adTitle: msg.adTitle || '',
        images: Array.isArray(msg.images) ? msg.images : [],
        text: typeof msg.text === 'string' ? msg.text : '',
        texts: msg.texts && typeof msg.texts === 'object' ? msg.texts : {},
        mode: msg.mode === 'text' ? 'text' : 'image',
        updatedAt: Date.now(),
      };
      await setState(next);
      if (msg.openFirst && next.queue.length) {
        chrome.tabs.create({ url: 'https://www.facebook.com/groups/' + next.queue[0] + '/?tareeq=1' });
      }
      sendResponse({ ok: true, state: next });
      return;
    }
    if (msg.type === 'GET_STATE') {
      sendResponse({ ok: true, state });
      return;
    }
    if (msg.type === 'FETCH_IMAGE') {
      try {
        const r = await fetch(msg.url);
        if (!r.ok) throw new Error('bad');
        const blob = await r.blob();
        const buf = await blob.arrayBuffer();
        const bytes = new Uint8Array(buf);
        let bin = '';
        const chunk = 0x8000;
        for (let i = 0; i < bytes.length; i += chunk) {
          bin += String.fromCharCode.apply(null, bytes.subarray(i, i + chunk));
        }
        sendResponse({ ok: true, mime: blob.type || 'image/jpeg', base64: btoa(bin) });
      } catch (e) {
        sendResponse({ ok: false, error: String(e && e.message || e) });
      }
      return;
    }
    if (msg.type === 'SYNC') {
      state.idx = typeof msg.idx === 'number' ? msg.idx : state.idx;
      if (msg.posted && typeof msg.posted === 'object') state.posted = msg.posted;
      await setState(state);
      sendResponse({ ok: true, state });
      return;
    }
    if (msg.type === 'ADVANCE') {
      const id = state.queue[state.idx];
      if (id) {
        state.posted = state.posted || {};
        state.posted[id] = new Date().toISOString();
      }
      state.idx = Math.min(state.idx + 1, state.queue.length);
      await setState(state);
      // open next group
      const nextId = state.queue[state.idx];
      if (nextId) {
        const url = 'https://www.facebook.com/groups/' + nextId + '/?tareeq=1';
        chrome.tabs.create({ url });
      }
      // notify admin tab
      broadcastToAdmin({ type: 'ADVANCED', id, idx: state.idx, posted: state.posted, done: state.idx >= state.queue.length });
      sendResponse({ ok: true, state });
      return;
    }
    if (msg.type === 'SKIP') {
      state.idx = Math.min(state.idx + 1, state.queue.length);
      await setState(state);
      const nextId = state.queue[state.idx];
      if (nextId) {
        const url = 'https://www.facebook.com/groups/' + nextId + '/?tareeq=1';
        chrome.tabs.create({ url });
      }
      broadcastToAdmin({ type: 'SKIPPED', idx: state.idx, done: state.idx >= state.queue.length });
      sendResponse({ ok: true, state });
      return;
    }
    if (msg.type === 'STOP') {
      await setState({ queue: [], idx: 0, posted: state.posted || {}, adTitle: '', updatedAt: Date.now() });
      broadcastToAdmin({ type: 'STOPPED' });
      sendResponse({ ok: true });
      return;
    }
    sendResponse({ ok: false, error: 'unknown type' });
  })();
  return true; // async
});

function broadcastToAdmin(payload) {
  chrome.tabs.query({ url: 'https://tareeq-eg.vercel.app/admin*' }, tabs => {
    for (const t of tabs || []) {
      chrome.tabs.sendMessage(t.id, { source: 'tareeq-bg', ...payload }).catch(() => {});
    }
  });
}