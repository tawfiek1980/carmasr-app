// TAREEQ standalone publisher popup
(function () {
  'use strict';

  const $ = (id) => document.getElementById(id);

  let parsedGroups = [];
  let selected = new Set();

  function cleanGroupName(raw) {
    let s = String(raw || '').trim();
    // Remove common FB UI suffixes that get glued to the name
    const suffixes = [
      /آخر\s*نشاط\s*منذ.*$/i,
      /غير\s*مقروءة.*$/i,
      /مرحبًا\s*بك\s*في.*$/i,
      /وافق\s*أحد\s*المسؤولين.*$/i,
      /حازت\s*.*?على\s*إعجاب.*$/i,
      /تم\s*التفاعل\s*مؤخرًا.*$/i,
      / financing.*$/i,
    ];
    for (const re of suffixes) s = s.replace(re, '').trim();
    // Trim trailing punctuation/spaces
    s = s.replace(/[\s·•]+$/g, '').trim();
    return s;
  }

  function parseGroups(text) {
    const map = new Map();
    for (const raw of String(text || '').split(/\r?\n/)) {
      const line = raw.trim();
      if (!line) continue;
      const href = line.match(/\/groups\/(\d{5,})/);
      const bare = line.match(/(?:^|\D)(\d{6,})(?:\D|$)/);
      const id = href?.[1] || (!/https?:/i.test(line) ? bare?.[1] : undefined);
      if (!id) continue;
      let name = '';
      const parts = line.split('|').map(s => s.trim());
      for (const p of parts) {
        const cleaned = cleanGroupName(p.replace(/https?:\/\/\S+/g, ''));
        if (cleaned && !/^\d{5,}$/.test(cleaned) && cleaned.length > 1) {
          name = cleaned;
          break;
        }
      }
      if (!name) name = 'جروب ' + id;
      if (!map.has(id)) map.set(id, { id, name: name.slice(0, 140), url: 'https://www.facebook.com/groups/' + id + '/' });
    }
    return [...map.values()];
  }

  function parseImages(text) {
    const tokens = String(text || '').split(/[\s\r\n]+/).map(s => s.trim()).filter(Boolean);
    const urls = [];
    for (const t of tokens) {
      if (/^https?:\/\//i.test(t)) urls.push(t);
      else if (/\.(jpe?g|png|webp|gif|avif)(\?|#|$)/i.test(t) && t.includes('/')) urls.push(t);
    }
    return urls;
  }

  // text field handlers
  $('copyText').addEventListener('click', async () => {
    const t = $('text').value.trim();
    if (!t) { $('hint').textContent = 'لا يوجد نص للنسخ'; $('hint').className = 'hint err'; return; }
    try {
      await navigator.clipboard.writeText(t);
      $('hint').textContent = 'اتنسخ النص ✓ — الصقه في FB (Ctrl+V) بعد الصورة';
      $('hint').className = 'hint ok';
    } catch {
      $('hint').textContent = 'تعذر النسخ — حدد النص وانسخ يدويًا';
      $('hint').className = 'hint err';
    }
  });

  function renderGroupList() {
    const list = $('groupList');
    list.innerHTML = '';
    parsedGroups.forEach(g => {
      const div = document.createElement('div');
      div.className = 'group-item';
      const cb = document.createElement('input');
      cb.type = 'checkbox';
      cb.checked = selected.has(g.id);
      cb.addEventListener('change', () => {
        if (cb.checked) selected.add(g.id); else selected.delete(g.id);
        updateStats();
      });
      const lbl = document.createElement('label');
      lbl.textContent = g.name + '  (' + g.id + ')';
      lbl.title = g.url;
      div.appendChild(cb);
      div.appendChild(lbl);
      list.appendChild(div);
    });
    updateStats();
  }

  function updateStats() {
    const im = parseImages($('images').value);
    const raw = $('images').value.trim();
    $('groupsStat').textContent = parsedGroups.length + ' جروب — ' + selected.size + ' محدد';
    $('imagesStat').textContent = im.length + ' صورة' + (raw && im.length === 0 ? '  ⚠️ (لم يُعثر على روابط — الصق روابط https)' : '');
  }

  $('groups').addEventListener('input', () => {
    parsedGroups = parseGroups($('groups').value);
    // default: select all newly parsed
    selected = new Set(parsedGroups.map(g => g.id));
    renderGroupList();
    saveState();
  });
  $('images').addEventListener('input', () => { updateStats(); saveState(); });
  $('text').addEventListener('input', saveState);

  // ── persistence ────────────────────────────────────────────────────────────
  function saveState() {
    chrome.storage.local.set({
      tareeq_groups_text: $('groups').value,
      tareeq_images_text: $('images').value,
      tareeq_text: $('text').value,
    });
  }

  async function loadSaved() {
    return new Promise(resolve => {
      chrome.storage.local.get(['tareeq_groups_text', 'tareeq_images_text', 'tareeq_text'], (r) => {
        if (r.tareeq_groups_text) $('groups').value = r.tareeq_groups_text;
        if (r.tareeq_images_text) $('images').value = r.tareeq_images_text;
        if (r.tareeq_text) $('text').value = r.tareeq_text;
        parsedGroups = parseGroups($('groups').value);
        selected = new Set(parsedGroups.map(g => g.id));
        renderGroupList();
        updateStats();
        resolve();
      });
    });
  }

  // initial load
  loadSaved();

  $('selectAll').addEventListener('click', () => {
    selected = new Set(parsedGroups.map(g => g.id));
    renderGroupList();
  });
  $('selectNone').addEventListener('click', () => {
    selected.clear();
    renderGroupList();
  });
  $('selectN').addEventListener('click', () => {
    const n = parseInt($('selCount').value, 10);
    if (!n || n < 1) return;
    selected = new Set(parsedGroups.slice(0, n).map(g => g.id));
    renderGroupList();
  });
  $('clearGroups').addEventListener('click', () => {
    if (!confirm('مسح كل الجروبات؟')) return;
    $('groups').value = '';
    parsedGroups = [];
    selected.clear();
    renderGroupList();
    updateStats();
    saveState();
  });

  async function getState() {
    return new Promise(resolve => {
      chrome.runtime.sendMessage({ type: 'GET_STATE' }, res => {
        resolve((res && res.state) || { queue: [], idx: 0, posted: {} });
      });
    });
  }

  async function refreshProgress() {
    const st = await getState();
    const total = st.queue.length;
    const idx = st.idx || 0;
    const postedCount = Object.keys(st.posted || {}).length;
    if (total === 0) {
      $('progressStat').textContent = '—';
      $('bar').style.width = '0%';
      $('hint').textContent = '—';
      return;
    }
    const cur = st.queue[idx];
    const pct = total ? Math.round((idx / total) * 100) : 0;
    $('bar').style.width = pct + '%';
    $('progressStat').textContent = 'الجروب ' + (idx + 1) + ' / ' + total + ' — نُشر ' + postedCount;
    $('hint').textContent = cur ? ('الحالي: ' + cur) : 'خلّصت كل الجروبات ✓';
    $('hint').className = 'hint ok';
  }

  $('start').addEventListener('click', async () => {
    const images = parseImages($('images').value);
    const text = ($('text').value || '').trim();
    const ids = [...selected];
    if (!ids.length) { $('hint').textContent = 'حدد جروب واحد على الأقل'; $('hint').className = 'hint err'; return; }
    if (!images.length && !text) { $('hint').textContent = 'أضف روابط صور أو نص البوست'; $('hint').className = 'hint err'; return; }
    const mode = (!images.length && text) ? 'text' : 'image';
    if (mode === 'text') {
      try {
        await navigator.clipboard.writeText(text);
        $('hint').textContent = '✅ النص اتنسخ — الصقه في كل منشور (Ctrl+V)';
        $('hint').className = 'hint ok';
      } catch { /* content script هيحاول ينسخ */ }
    }
    await chrome.storage.local.set({ tareeq_images: images });
    chrome.runtime.sendMessage({
      type: 'START_QUEUE', queue: ids, adTitle: 'إعلان',
      images: mode === 'text' ? [] : images,
      text: mode === 'text' ? text : '',
      mode,
      openFirst: true,
    }, (res) => {
      if (res && res.ok) {
        $('hint').textContent = mode === 'text'
          ? 'بدأ النشر — افتح جروب ١ والصق النص (Ctrl+V)'
          : 'بدأ النشر — افتح جروب ١ وانشر (Ctrl+V)';
        $('hint').className = 'hint ok';
        refreshProgress();
        chrome.tabs.create({ url: 'https://www.facebook.com/groups/' + ids[0] + '/?tareeq=1' });
      } else {
        $('hint').textContent = 'فشل البدء';
        $('hint').className = 'hint err';
      }
    });
  });

  $('advance').addEventListener('click', () => {
    chrome.runtime.sendMessage({ type: 'ADVANCE' }, () => refreshProgress());
  });
  $('skip').addEventListener('click', () => {
    chrome.runtime.sendMessage({ type: 'SKIP' }, () => refreshProgress());
  });
  $('stop').addEventListener('click', () => {
    if (!confirm('إيقاف الطابور؟')) return;
    chrome.runtime.sendMessage({ type: 'STOP' }, () => refreshProgress());
  });

  setInterval(refreshProgress, 1500);
  refreshProgress();
  updateStats();
})();